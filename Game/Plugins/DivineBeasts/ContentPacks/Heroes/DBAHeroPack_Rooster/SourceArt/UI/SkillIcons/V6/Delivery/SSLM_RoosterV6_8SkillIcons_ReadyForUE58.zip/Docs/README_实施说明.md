# SSLM 酉鸡金鸣 V6 八技能纹理交付说明

本包基于会话中已生成并可用的八幅1254×1254独立图像，按稳定技能顺序(1金羽击/2破晓/3晨鸣波/4破晓金鸣/5鸣步/6金羽/7鸣震/8晨鸣)冻结视觉，不更改V5正式玩法授权。

- `SourceArt/Masters`：8份1254px经高光压缩的正式候选母稿；无虚构2048px重绘。
- `Review/64`：8份原生64×64 PNG审查纹理。
- `Runtime/48`：8份原生48×48 PNG正式运行素材。
- `Review/Preview256`：独立256px缩图，对照检查。
- `Review/*ContactSheet.png`：小尺寸像素级最近邻放大对照，方便人工检查。
- `Review/RoosterV6_8Slots_48px_Actual.png`：8个图标横排，保持原生48像素，无游戏HUD装饰。
- `Docs/RoosterV6SkillIconManifest.json`：AbilityId、SlotId、拟定正式UE Texture2D挂载点与SHA-256。
- `Docs/RoosterV6IconQAReport.json`：文件尺寸、唯一性、亮度等预检。

## 工程导入

1. 整包解压至工作区的`Game/Saved/ArtReview/RoosterV6/`；或按脚本清单将纹理复制至本英雄内容包`SourceArt/UI/SkillIcons/V6`。必须保留清单中的稳定AbilityId，不根据中文名推导。
2. 采用 UE5.8 Editor＋Monolith在 `/DBAHeroPack_Rooster/UI/Abilities/V6/Textures/` 导入`Runtime/48`八张PNG成为真Texture2D；设置sRGB=true、UI专用压缩、关闭Mipmaps并确认原生48×48。
3. 备份已有`DA_DBA_Rooster_PlaceholderUIProfile.uasset`，只在该唯一主资产添加八条AbilityId→中文名/描述/软图标路径，保留所有旧条目，冲突停止。仅作为只读美术表现，不得授予GAS能力。
4. 复用现有 `UDivineBeastsAbilityBarViewModel`（技能栏视图模型）及GamePlatformData资源租约机制，从真实Loadout（技能授权装配）读取已授权技能；无授权时应维持0技能，不得为展示强制修改授权。只读ArtPreviewAbilityIds可以展示本批8张。
5. UE编辑器真实保存、冷重载、64/48画质审核，新手村及战斗HUD实际截屏与日志验收后才标注完成。

## 已知限制

HWebCodex远程收件接口尝试直接接收ChatGPT生成图像时返回`host-provided download URL resolves to a non-public address`，故本包不能被宣称已自动写入远程Windows项目，也不包含已导入的`.uasset`。此前鸡包已有5份V1纹理，严禁直接覆盖。
