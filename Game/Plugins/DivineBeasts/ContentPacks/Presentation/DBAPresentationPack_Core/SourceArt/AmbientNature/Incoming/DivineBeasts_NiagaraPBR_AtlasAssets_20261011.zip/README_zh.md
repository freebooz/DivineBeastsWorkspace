# 神兽联盟 Niagara PBR 资产源包

本包由当前对话六张图集拆分生成，包含6张原始图集和33类精灵的独立颜色（含透明）、法线、粗糙度、透明遮罩PNG，共132张纹理，以及原图SHA-256与每张纹理哈希记录。

## 使用范围与三层归属

- 平台基础层 `GamePlatformVFX（游戏平台视觉特效插件）`：通用Niagara播放、运动模块、PBR母材质和性能预算。不硬引用项目专有纹理。
- MOBA公共层：不新增纯装饰业务代码。
- 项目层 `DBAPresentationPack_Core（神兽联盟公共视觉内容包）`：33种外观的独立PBR纹理和材质实例，按原AssetId软资源绑定。角色创建/选择与Village/OpenWorld由项目侧区域预设决定风格。

## 数据质量门禁

- `auto_candidate`：可进入UE5.8编辑器预览/替换候选，不代表最终验收；一般为规则四通道展示图集提取的独立花瓣或树叶。
- `review_only`：局部源图边缘被展示拼版截断，或多面板通道无法准确对齐；禁止自动替换。
- `fx_reference_only`：灰烬、蒲公英、柳絮、萤火虫等属于FX示意图，图中多个对象/通道未做单体物理扫描，不用于替换已有运行时粒子。

真正的PBR扫描应当来自实物高质量拍摄/法线与粗糙度精确测量；图像生成的通道仅做估算，无法保证物理真实，需在UE5.8 D3D12与目标设备进行光照和GPU实测。纹理尺寸为512×512，原始展示图每格只有约200像素，不应把插值放大到4K并宣称真实细节提升。

## 导入方式

将本ZIP复制到Windows工程：
`Game/Plugins/DivineBeasts/ContentPacks/Presentation/DBAPresentationPack_Core/SourceArt/AmbientNature/Incoming/DivineBeasts_NiagaraPBR_AtlasAssets_20261011.zip`

在UE5.8编辑器内运行 `Tools/Unreal/VFX/FallingFoliage/ImportPBRAtlasAssetsUE58.py`，默认仅核对哈希并dry-run；经人工审核设置 `AMBIENT_PBR_APPLY=approved_apply` 后才备份并重导候选贴图和项目材质实例。决不手工伪造.uasset。

现有被其他编辑器任务占用的资源必须待解除占用后再导入，保留旧纹理/材质备份、项目挂载名与原Niagara运动资源身份。
